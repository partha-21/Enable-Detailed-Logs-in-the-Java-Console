package com.logger.handlers;

import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;

public class DetailedConsoleHandler extends StreamHandler {

    public DetailedConsoleHandler() {
        super(System.out, new java.util.logging.SimpleFormatter());
    }

    @Override
    public void publish(LogRecord record) {
        super.publish(record);
        flush();
    }

    @Override
    public void close() {
        flush();
    }
}
