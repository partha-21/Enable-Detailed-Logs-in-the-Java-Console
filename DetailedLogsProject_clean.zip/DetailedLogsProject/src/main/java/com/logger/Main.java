package com.logger;

import com.logger.config.LoggerConfig;
import com.logger.demo.ConnectionDemo;

public class Main {

    public static void main(String[] args) {
        LoggerConfig.initialize();

        System.out.println("==========================================================");
        System.out.println("  Enable Detailed Logs — Java Console Demo");
        System.out.println("==========================================================");
        System.out.println("  Java Control Panel → Advanced → Java Console → Show");
        System.out.println("  All log levels: FINEST → FINER → FINE → INFO → WARNING → SEVERE");
        System.out.println("==========================================================\n");

        ConnectionDemo demo = new ConnectionDemo();
        demo.runAll();

        System.out.println("\n[Main] Done. Check logs/ folder for the full file log.");
    }
}
