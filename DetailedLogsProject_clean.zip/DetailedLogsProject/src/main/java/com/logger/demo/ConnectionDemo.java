package com.logger.demo;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionDemo {

    private static final Logger LOG = Logger.getLogger(ConnectionDemo.class.getName());

    public void runAll() {
        scenario1_SuccessfulConnection();
        separator();
        scenario2_ConnectionRefused();
        separator();
        scenario3_SslBlocked();
        separator();
        scenario4_SecurityManagerDenial();
        separator();
        scenario5_Timeout();
    }

    private void scenario1_SuccessfulConnection() {
        LOG.info("── Scenario 1: Successful Connection ──");
        LOG.finest("Reading deployment configuration from deployment.properties");
        LOG.finer ("Resolving host: remote-console.example.com");
        LOG.fine  ("DNS resolved → 203.0.113.42");
        LOG.fine  ("Opening TCP socket to 203.0.113.42:1099");
        LOG.finer ("TCP handshake complete (SYN/SYN-ACK/ACK)");
        LOG.info  ("Connected to remote-console.example.com:1099");
        LOG.fine  ("Sending RMI stub request");
        LOG.finer ("RMI stub received (3 824 bytes)");
        LOG.info  ("Remote console launched successfully ✓");
    }

    private void scenario2_ConnectionRefused() {
        LOG.info("── Scenario 2: Connection Refused ──");
        LOG.finest("Reading deployment configuration");
        LOG.finer ("Resolving host: remote-console.example.com");
        LOG.fine  ("DNS resolved → 203.0.113.42");
        LOG.fine  ("Opening TCP socket to 203.0.113.42:1098");
        LOG.warning("TCP connect failed: Connection refused (203.0.113.42:1098)");
        LOG.warning("Possible causes: wrong port number, service not running, or firewall DROP rule");
        LOG.severe ("BLOCKED — Remote console could not be reached. Check port 1098 is open.");

        Exception ex = new java.net.ConnectException("Connection refused: connect (203.0.113.42:1098)");
        LOG.log(Level.SEVERE, "Connection attempt failed with exception", ex);
    }

    private void scenario3_SslBlocked() {
        LOG.info("── Scenario 3: SSL Handshake Blocked ──");
        LOG.finest("Initiating TLS 1.3 handshake with remote-console.example.com:443");
        LOG.finer ("Sending ClientHello");
        LOG.finer ("ServerHello received");
        LOG.fine  ("Server certificate chain: [remote-console.example.com, ExampleCA]");
        LOG.warning("Certificate CN mismatch: expected 'remote-console.example.com', got 'old-console.example.com'");
        LOG.warning("Java security policy: certificate not trusted (not in cacerts keystore)");
        LOG.severe ("REFUSED — SSL handshake aborted. Add the server certificate to your truststore or fix the CN.");

        Exception ex = new javax.net.ssl.SSLHandshakeException(
                "PKIX path building failed: unable to find valid certification path to requested target");
        LOG.log(Level.SEVERE, "SSL error detail", ex);
    }

    private void scenario4_SecurityManagerDenial() {
        LOG.info("── Scenario 4: Security Manager Denial ──");
        LOG.finest("Applet / JNLP requesting socket permission for 203.0.113.42:1099");
        LOG.finer ("Checking policy file: /etc/java/security/java.policy");
        LOG.fine  ("Policy entry found for codeBase 'http://remote-console.example.com/'");
        LOG.warning("Permission java.net.SocketPermission '203.0.113.42:1099' action 'connect' — DENIED");
        LOG.warning("No matching grant block in java.policy for this codeBase + permission combination");
        LOG.severe ("BLOCKED by Security Manager. Add the following to java.policy:");
        LOG.severe ("  grant codeBase \"http://remote-console.example.com/-\" {");
        LOG.severe ("    permission java.net.SocketPermission \"203.0.113.42:1099\", \"connect,resolve\";");
        LOG.severe ("  };");

        Exception ex = new SecurityException(
                "access denied (java.net.SocketPermission 203.0.113.42:1099 connect,resolve)");
        LOG.log(Level.SEVERE, "Security manager exception", ex);
    }

    private void scenario5_Timeout() {
        LOG.info("── Scenario 5: Connection Timeout ──");
        LOG.finest("Reading deployment configuration");
        LOG.finer ("Resolving host: remote-console.example.com");
        LOG.fine  ("DNS resolved → 203.0.113.42");
        LOG.fine  ("Opening TCP socket to 203.0.113.42:1099 (timeout=10 000 ms)");

        for (int i = 1; i <= 3; i++) {
            LOG.finer("Waiting for SYN-ACK ... attempt " + i + "/3");
        }

        LOG.warning("Socket connect timed out after 10 000 ms");
        LOG.warning("Possible causes: host unreachable, firewall silently dropping packets (no RST sent)");
        LOG.severe ("REFUSED — Connection timed out. Verify the host is reachable (ping / traceroute) "
                  + "and that no intermediate firewall is dropping the SYN packet silently.");

        Exception ex = new java.net.SocketTimeoutException("connect timed out (10000 ms)");
        LOG.log(Level.SEVERE, "Timeout exception detail", ex);
    }

    private void separator() {
        System.out.println();
    }
}
