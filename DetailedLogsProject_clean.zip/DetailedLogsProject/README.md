# Enable Detailed Logs — Java Console

Enables full verbose logging in a Java console app — the programmatic equivalent of:
> Java Control Panel → Advanced → Java Console → **Show console**

## Project Structure

```
src/main/java/com/logger/
├── Main.java
├── config/
│   ├── LoggerConfig.java
│   └── DetailedFormatter.java
├── handlers/
│   └── DetailedConsoleHandler.java
└── demo/
    └── ConnectionDemo.java
src/main/resources/
└── logging.properties
logs/
```

## Log Levels

| Level | Description |
|-------|-------------|
| `FINEST` | Internal trace (DNS, TCP SYN, policy checks) |
| `FINER` | Handshake steps, retry counts |
| `FINE` | Socket open, cert chain |
| `INFO` | Key milestones |
| `WARNING` | Possible problems |
| `SEVERE` | Hard failures with fix hints |

## Build & Run

```cmd
cd DetailedLogsProject
mkdir out
mkdir logs
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt
java -cp out com.logger.Main
```

## Scenarios

| # | Result | Description |
|---|--------|-------------|
| 1 | ✅ | Successful connection |
| 2 | ❌ | Connection refused (wrong port / firewall) |
| 3 | ❌ | SSL certificate mismatch |
| 4 | ❌ | Security Manager denial |
| 5 | ❌ | Connection timeout |

Full log saved to `logs/app.log`.
