package com.logger.config;

import com.logger.handlers.DetailedConsoleHandler;

import java.io.IOException;
import java.util.logging.*;

public class LoggerConfig {

    private static final String LOG_FILE = "logs/app.log";

    public static void initialize() {
        Logger root = Logger.getLogger("");
        for (Handler h : root.getHandlers()) {
            root.removeHandler(h);
        }

        root.setLevel(Level.FINEST);

        DetailedConsoleHandler consoleHandler = new DetailedConsoleHandler();
        consoleHandler.setLevel(Level.FINEST);
        consoleHandler.setFormatter(new DetailedFormatter(true));
        root.addHandler(consoleHandler);

        try {
            FileHandler fileHandler = new FileHandler(LOG_FILE, true);
            fileHandler.setLevel(Level.FINEST);
            fileHandler.setFormatter(new DetailedFormatter(false));
            root.addHandler(fileHandler);
        } catch (IOException e) {
            root.warning("Could not open log file " + LOG_FILE + ": " + e.getMessage());
        }

        root.info("Logging initialised — level=FINEST, console=ON, file=" + LOG_FILE);
    }
}
