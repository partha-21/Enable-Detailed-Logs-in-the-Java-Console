package com.logger.config;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

public class DetailedFormatter extends Formatter {

    private static final String RESET   = "\u001B[0m";
    private static final String RED     = "\u001B[31m";
    private static final String YELLOW  = "\u001B[33m";
    private static final String CYAN    = "\u001B[36m";
    private static final String GREEN   = "\u001B[32m";
    private static final String MAGENTA = "\u001B[35m";
    private static final String WHITE   = "\u001B[37m";
    private static final String BOLD    = "\u001B[1m";

    private static final DateTimeFormatter TS_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
                             .withZone(ZoneId.systemDefault());

    private final boolean useColour;

    public DetailedFormatter(boolean useColour) {
        this.useColour = useColour;
    }

    @Override
    public String format(LogRecord record) {
        String timestamp = TS_FMT.format(Instant.ofEpochMilli(record.getMillis()));
        String level     = padLevel(record.getLevel());
        String source    = shortSource(record.getLoggerName());
        String message   = formatMessage(record);

        StringBuilder sb = new StringBuilder();

        if (useColour) {
            sb.append(WHITE).append("[").append(timestamp).append("]").append(RESET);
            sb.append("  ");
            sb.append(levelColour(record.getLevel())).append(BOLD).append(level).append(RESET);
            sb.append("  ");
            sb.append(CYAN).append("[").append(source).append("]").append(RESET);
            sb.append("  ");
            sb.append(messageColour(record.getLevel())).append(message).append(RESET);
        } else {
            sb.append("[").append(timestamp).append("]");
            sb.append("  ").append(level);
            sb.append("  [").append(source).append("]");
            sb.append("  ").append(message);
        }

        sb.append(System.lineSeparator());

        if (record.getThrown() != null) {
            Throwable t = record.getThrown();
            sb.append("  Caused by: ").append(t).append(System.lineSeparator());
            for (StackTraceElement el : t.getStackTrace()) {
                sb.append("    at ").append(el).append(System.lineSeparator());
            }
        }

        return sb.toString();
    }

    private String padLevel(Level level) {
        return String.format("%-7s", level.getName());
    }

    private String shortSource(String loggerName) {
        if (loggerName == null || loggerName.isEmpty()) return "root";
        int dot = loggerName.lastIndexOf('.');
        return dot >= 0 ? loggerName.substring(dot + 1) : loggerName;
    }

    private String levelColour(Level level) {
        if (level == Level.SEVERE)  return RED;
        if (level == Level.WARNING) return YELLOW;
        if (level == Level.INFO)    return GREEN;
        if (level == Level.FINE)    return CYAN;
        return MAGENTA;
    }

    private String messageColour(Level level) {
        if (level == Level.SEVERE)  return RED;
        if (level == Level.WARNING) return YELLOW;
        return RESET;
    }
}
